module.exports = {
  secret: "rahim -secret-key"
};
